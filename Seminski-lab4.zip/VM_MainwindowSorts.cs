﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Documents;
using LiveCharts.Defaults;
using System.Windows;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using LiveCharts;
using LiveCharts.Wpf;
using AlgLab4.Model;

namespace AlgLab4
{
    class VM_MainwindowSorts : INotifyPropertyChanged
    {
        private int _step;
        private int _arraySize;
        private string _selectedSort;
        private List<string> _typesSortsList = new List<string> { "Counting Sort", "Bubble Sort", "Merge Sort" };
        private RelayCommand _execute;
        private SeriesCollection _seriesCollection;

        public VM_MainwindowSorts()
        {
            //ObservablePoint obserPoint = new ObservablePoint();
            //obserPoint.X = 2;
            //obserPoint.Y = 2;

            //ChartValues<ObservablePoint> chartValues = new ChartValues<ObservablePoint>();

            //chartValues.Add(obserPoint);
            //chartValues.Add(new ObservablePoint { X = 7, Y = 5 });

            //SeriesCollection = new SeriesCollection
            //{
            //    new LineSeries
            //    {
            //        Values = chartValues
            //    }
            //};
        }

        public SeriesCollection SeriesCollection
        {
            get => _seriesCollection;
            set
            {
                _seriesCollection = value;
                OnPropertyChanged();
            }
        }

        public int Step
        {
            get => _step;
            set
            {
                _step = value;
                OnPropertyChanged();
            }
        }

        public int ArraySize
        {
            get => _arraySize;
            set
            {
                _arraySize = value;
                OnPropertyChanged();
            }
        }
        public string SelectedSort
        {
            get => _selectedSort;
            set
            {
                _selectedSort = value;
                OnPropertyChanged();
            }
        }
        public List<string> TypesSortsList
        {
            get => _typesSortsList;
            set
            {
                _typesSortsList = value;
                OnPropertyChanged();
            }
        }
        public int[] Array { get; set; }
        public RelayCommand Execute
        {
            get => _execute ??
               (_execute = new RelayCommand(obj =>
               {
                   switch (SelectedSort)
                   {
                       case "Counting Sort":
                           SeriesCollection = new SeriesCollection
                           {
                                new LineSeries
                                {
                                    Values = createChartValues(Model_sorts.getExecutionTimeByArraySizeCountingSort(ArraySize,Step))
                                }
                           };
                           break;
                       case "Bubble Sort":
                           SeriesCollection = new SeriesCollection
                           {
                                new LineSeries
                                {
                                    Values = createChartValues(Model_sorts.getExecutionTimeByArraySizeBubleSort(ArraySize,Step))
                                }
                           };
                           break;
                       case "Merge Sort":
                           SeriesCollection = new SeriesCollection
                           {
                                new LineSeries
                                {
                                    Values = createChartValues(Model_sorts.getExecutionTimeByArraySizeMergeSort(ArraySize,Step))
                                }
                           };
                           break;
                       default:
                           break;
                   }                 
               }));
        }

        public ChartValues<ObservablePoint> createChartValues(Dictionary<int, double> pointInfos)
        {
            ChartValues<ObservablePoint> chartValues = new ChartValues<ObservablePoint>();
            foreach (int key in pointInfos.Keys)
            {
                chartValues.Add(new ObservablePoint { X = key, Y = pointInfos[key] });
            }
            return chartValues;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged([CallerMemberName]string prop = "")
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(prop));
        }
    }
}
