﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace AlgLab4.Model
{
    class Model_sorts
    {
        public static Dictionary<int, double> getExecutionTimeByArraySizeCountingSort(int arraySize, int step)
        {
            Dictionary<int, double> timeArraySize = new Dictionary<int, double>();
            Stopwatch stopwatch = new Stopwatch();
            int[] array;
            int amountIteration = arraySize / step;
            int count = 0;
            for (int i = 0; i < amountIteration; i++)
            {
                count += step;
                array = getRandomArray(count);

                stopwatch.Start();
                int [] a = Counting.Sort(array);
                stopwatch.Stop();

                timeArraySize.Add(array.Length, stopwatch.ElapsedMilliseconds);
            }
            return timeArraySize;
        }

        public static Dictionary<int, double> getExecutionTimeByArraySizeBubleSort(int arraySize, int step)
        {
            Dictionary<int, double> timeArraySize = new Dictionary<int, double>();
            Stopwatch stopwatch = new Stopwatch();
            int[] array;
            int amountIteration = arraySize / step;
            int count = 0;
            for (int i = 0; i < amountIteration; i++)
            {
                count += step;
                array = getRandomArray(count);

                stopwatch.Start();
                Bubble.Sort(array);
                stopwatch.Stop();

                timeArraySize.Add(array.Length, stopwatch.ElapsedMilliseconds);
            }
            return timeArraySize;
        }

        public static Dictionary<int, double> getExecutionTimeByArraySizeMergeSort(int arraySize, int step)
        {
            Dictionary<int, double> timeArraySize = new Dictionary<int, double>();
            Stopwatch stopwatch = new Stopwatch();
            int[] array;
            int amountIteration = arraySize / step;
            int count = 0;
            for (int i = 0; i < amountIteration; i++)
            {
                count += step;
                array = getRandomArray(count);

                stopwatch.Start();
                Merge.MergeSort(array);
                stopwatch.Stop();

                timeArraySize.Add(array.Length, stopwatch.ElapsedMilliseconds);
            }
            return timeArraySize;
        }


        private static int[] getRandomArray(int sizeArray)
        {
            int[] array = new int[sizeArray];
            for (int i = 0; i < sizeArray; i++)
            {
                Random rand = new Random(i);
                array[i] = rand.Next(0, 100000);
            }
            return array;
        } 

    }
}
