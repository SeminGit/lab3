﻿using System;
using System.Collections.Generic;

namespace lab_3
{
    class Program
    {
        static Random random = new Random();
        static int[] newArray(int size)
        {
            int[] a = new int[size];
            for (int i = 0; i < size; i++)
            {
                a[i] = random.Next(-100, 100);
            }
            return a;
        }
        static void Main(string[] args)
        {
            int task;
            do
            {
                Console.Clear();
                Console.WriteLine("Enter task 2-4: ");
                task = Convert.ToInt32(Console.ReadLine());
                switch (task)
                {
                    case 2:
                        {
                            Console.WriteLine("Enter k:  ");
                            int k = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Enter n: ");
                            int n = Convert.ToInt32(Console.ReadLine());
                            List<int[]> arrays = new List<int[]>();

                            for (int i = 0; i < k; i++)
                            {
                                // new array returns array of size n with random values up to 10
                                arrays.Add(newArray(n));
                            }
                            Console.WriteLine("before:");
                            int count = 0;
                            foreach (int[] item in arrays)
                            {
                                count += item.Length;
                                for (int h = 0; h < n; h++)
                                {
                                    Console.Write(item[h] + " ");
                                }
                                Console.WriteLine('\n');
                            }
                            int[] final = new int[count];
                            int f = 0;
                            for (int i = 0; i < k; i++)
                            {
                                for (int j = 0; j < arrays[i].Length; j++)
                                {
                                    final[f] = arrays[i][j];
                                    f++;
                                }
                            }
                            for (int i = 0; i < final.Length; i++)
                            {
                                Console.Write(final[i] + "  ");
                            }
                            Console.WriteLine();
                            MergeSort(final, 0, final.Length - 1);
                            Console.WriteLine("After: ");

                            for (int i = 0; i < final.Length; i++)
                            {
                                Console.Write(final[i] + " ");
                            }
                            Console.ReadKey();
                            break;
                        }
                    case 3:
                        {
                            int size = random.Next(10);
                            string abc = "abcdefghijklmnopqrstuvwxyz";
                            string[] array = new string[size];
                            for (int i = 0; i < size; i++)
                            {
                                for (int j = 0; j < random.Next(5, 10); j++)
                                {
                                    array[i] += abc[random.Next(abc.Length - 1)];
                                }
                            }
                            Console.WriteLine("\n before: ");
                            for (int i = 0; i < size; i++)
                            {
                                Console.Write(array[i] + " ");
                            }
                            MergeSortForSrings(array, 0, array.Length - 1);

                            Console.WriteLine("\n after: ");
                            for (int i = 0; i < size; i++)
                            {
                                Console.Write(array[i] + " ");
                            }
                            Console.ReadKey();
                            break;
                        }
                    case 4:
                        {
                            Console.WriteLine("Enter n then m : ");
                            int n = Convert.ToInt32(Console.ReadLine());
                            int m = Convert.ToInt32(Console.ReadLine());

                            Random random = new Random();

                            int[] array = new int[n];
                            for (int i = 0; i < n; i++)
                            {
                                array[i] = random.Next(1, m);
                            }

                            Console.WriteLine("\n before: ");

                            for (int i = 0; i < n; i++)
                            {
                                Console.Write(array[i] + " ");
                            }

                            int[] equal = CountKeysEqual(array, n, n);
                            int[] less = CountKeysLess(equal, m);

                            int[] newArray2 = RearrangeProcedure(array, less, n, m);

                            Console.WriteLine("\n after: ");

                            for (int i = 0; i < n; i++)
                            {
                                Console.Write(newArray2[i] + " ");
                            }
                            Console.ReadKey();
                            break;
                        }
                }
            }
            while (task != 0);
        }

        static void MergeProcForStrings(string[] array, int lowIndex, int middleIndex, int highIndex)
        {
            var left = lowIndex;
            var right = middleIndex + 1;
            var tempArray = new string[highIndex - lowIndex + 1];
            var index = 0;

            while ((left <= middleIndex) && (right <= highIndex))
            {
                if (array[left].CompareTo(array[right]) < 1)
                {
                    tempArray[index] = array[left];
                    left++;
                }
                else
                {
                    tempArray[index] = array[right];
                    right++;
                }

                index++;
            }

            for (var i = left; i <= middleIndex; i++)
            {
                tempArray[index] = array[i];
                index++;
            }

            for (var i = right; i <= highIndex; i++)
            {
                tempArray[index] = array[i];
                index++;
            }

            for (var i = 0; i < tempArray.Length; i++)
            {
                array[lowIndex + i] = tempArray[i];
            }
        }
        static void MergeProc(int[] array, int lowIndex, int middleIndex, int highIndex)
        {
            var left = lowIndex;
            var right = middleIndex + 1;
            var tempArray = new int[highIndex - lowIndex + 1];
            var index = 0;

            while ((left <= middleIndex) && (right <= highIndex))
            {
                if (array[left] < array[right])
                {
                    tempArray[index] = array[left];
                    left++;
                }
                else
                {
                    tempArray[index] = array[right];
                    right++;
                }

                index++;
            }
            //add all if left in left one
            for (var i = left; i <= middleIndex; i++)
            {
                tempArray[index] = array[i];
                index++;
            }
            // add all if left in right one
            for (var i = right; i <= highIndex; i++)
            {
                tempArray[index] = array[i];
                index++;
            }
            for (var i = 0; i < tempArray.Length; i++)
            {
                array[i] = tempArray[i];
            }
        }

        //сортировка слиянием
        static int[] MergeSort(int[] array, int lowIndex, int highIndex)
        {
            if (lowIndex < highIndex)
            {
                var middleIndex = (lowIndex + highIndex) / 2;
                MergeSort(array, lowIndex, middleIndex);
                MergeSort(array, middleIndex + 1, highIndex);
                MergeProc(array, lowIndex, middleIndex, highIndex);
            }

            return array;
        }
        static string[] MergeSort(string[] array, int lowIndex, int highIndex)
        {
            if (lowIndex < highIndex)
            {
                var middleIndex = (lowIndex + highIndex) / 2;
                MergeSort(array, lowIndex, middleIndex);
                MergeSort(array, middleIndex + 1, highIndex);
                MergeProcForStrings(array, lowIndex, middleIndex, highIndex);
            }

            return array;
        }
        static string[] MergeSortForSrings(string[] array, int lowIndex, int highIndex)
        {
            if (lowIndex < highIndex)
            {
                var middleIndex = (lowIndex + highIndex) / 2;
                MergeSort(array, lowIndex, middleIndex);
                MergeSort(array, middleIndex + 1, highIndex);
                MergeProcForStrings(array, lowIndex, middleIndex, highIndex);
            }

            return array;
        }
        public static int[] MergeSort(int[] array)
        {
            return MergeSort(array, 0, array.Length - 1);
        }

        public static int[] CountKeysEqual(int[] array, int n, int m)
        {
            int key;

            int[] equal = new int[m];
            for (int i = 0; i < m; i++)
            {
                equal[i] = 0;
            }

            for (int i = 0; i < n; i++)
            {
                key = array[i];
                equal[key - 1]++;
            }
            return equal;
        }

        public static int[] CountKeysLess(int[] equal, int m)
        {
            int[] less = new int[m];
            less[0] = 0;
            for (int i = 1; i < m; i++)
            {
                less[i] = less[i - 1] + equal[i - 1];
            }
            return less;
        }

        public static int[] RearrangeProcedure(int[] array, int[] less, int n, int m)
        {
            int key, index;

            int[] result = new int[n];
            int[] next = new int[m];

            for (int j = 0; j < m; j++)
            {
                next[j] = less[j] + 1;
            }

            for (int i = 0; i < n; i++)
            {
                key = array[i];
                index = next[key - 1];
                result[index - 1] = array[i];
                next[key - 1]++;
            }

            return result;
        }
    }
}
